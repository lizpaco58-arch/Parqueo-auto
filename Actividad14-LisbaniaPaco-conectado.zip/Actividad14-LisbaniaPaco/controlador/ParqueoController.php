<?php
require_once __DIR__ . "/../modelo/Parqueo.php";
require_once __DIR__ . "/../modelo/ParqueoDao.php";

class ParqueoController
{
    private $dao;
    private $carpetaFotos;
    const MAX_BYTES = 2097152; // 2 MB

    // CONSTRUCTOR
    public function __construct($dao)
    {
        $this->dao = $dao;
        $this->carpetaFotos = __DIR__ . "/../public/uploads/";
    }

    // LISTAR
    public function index()
    {
        $buscar = isset($_GET["buscar"]) ? trim($_GET["buscar"]) : "";
        $parqueos = $this->dao->listar($buscar);
        require __DIR__ . "/../vista/productos/index.php";
    }

    // NUEVO
    public function nuevo()
    {
        $parqueo = new Parqueo();
        $this->mostrarFormulario($parqueo, true, null);
    }

    // GUARDAR
    public function guardar()
    {
        $this->soloPost();
        $parqueo = $this->leerFormulario();
        $error = $this->validar($parqueo);

        if ($error === null && $parqueo->getId() !== null
            && $this->dao->buscarPorId($parqueo->getId()) !== null) {
            $error = "Ya existe un auto con el Id " . $parqueo->getId() . ".";
        }
        if ($error === null && $this->dao->placaExiste($parqueo->getPlaca(), null)) {
            $error = "La placa " . $parqueo->getPlaca() . " ya está registrada.";
        }

        $foto = "";
        if ($error === null) {
            list($foto, $error) = $this->subirFoto();
        }
        if ($error !== null) {
            $this->mostrarFormulario($parqueo, true, $error);
            return;
        }

        $parqueo->setFotografia($foto);
        try {
            $this->dao->insertar($parqueo);
        } catch (PDOException $e) {
            $this->borrarFoto($foto);
            $this->mostrarFormulario($parqueo, true, "No se pudo guardar: " . $e->getMessage());
            return;
        }
        $this->redirigir("Auto registrado correctamente.");
    }

    // EDITAR
    public function editar()
    {
        $id = isset($_GET["id"]) ? $_GET["id"] : "";
        $parqueo = $this->dao->buscarPorId($id);
        if ($parqueo === null) {
            $this->redirigir("El auto no existe.", "error");
        }
        $this->mostrarFormulario($parqueo, false, null);
    }

    // ACTUALIZAR
    public function actualizar()
    {
        $this->soloPost();
        $parqueo = $this->leerFormulario();
        $actual = $this->dao->buscarPorId($parqueo->getId());
        if ($actual === null) {
            $this->redirigir("El auto no existe.", "error");
        }

        $error = $this->validar($parqueo);
        if ($error === null && $this->dao->placaExiste($parqueo->getPlaca(), $parqueo->getId())) {
            $error = "La placa " . $parqueo->getPlaca() . " ya está registrada en otro auto.";
        }

        $nueva = "";
        if ($error === null) {
            list($nueva, $error) = $this->subirFoto();
        }
        if ($error !== null) {
            $parqueo->setFotografia($actual->getFotografia());
            $this->mostrarFormulario($parqueo, false, $error);
            return;
        }

        // Si no se subió foto nueva se conserva la anterior
        $parqueo->setFotografia($nueva !== "" ? $nueva : $actual->getFotografia());
        try {
            $this->dao->actualizar($parqueo);
        } catch (PDOException $e) {
            $this->borrarFoto($nueva);
            $parqueo->setFotografia($actual->getFotografia());
            $this->mostrarFormulario($parqueo, false, "No se pudo actualizar: " . $e->getMessage());
            return;
        }
        if ($nueva !== "") {
            $this->borrarFoto($actual->getFotografia());
        }
        $this->redirigir("Auto actualizado correctamente.");
    }

    // ELIMINAR
    public function eliminar()
    {
        $this->soloPost();
        $id = isset($_POST["id"]) ? $_POST["id"] : "";
        $parqueo = $this->dao->buscarPorId($id);
        if ($parqueo === null) {
            $this->redirigir("El auto no existe.", "error");
        }
        $this->dao->eliminar($id);
        $this->borrarFoto($parqueo->getFotografia());
        $this->redirigir("Auto eliminado.");
    }

    // ==========================================
    // AUXILIARES
    // ==========================================
    private function mostrarFormulario($parqueo, $esNuevo, $error)
    {
        require __DIR__ . "/../vista/productos/formulario.php";
    }

    private function soloPost()
    {
        if ($_SERVER["REQUEST_METHOD"] !== "POST") {
            header("Location: index.php");
            exit;
        }
        // Si la foto supera post_max_size de php.ini, PHP descarta todo el formulario
        if (empty($_POST) && isset($_SERVER["CONTENT_LENGTH"]) && $_SERVER["CONTENT_LENGTH"] > 0) {
            $this->redirigir("El archivo enviado supera el tamaño máximo permitido por el servidor.", "error");
        }
    }

    private function redirigir($mensaje, $tipo = "ok")
    {
        $_SESSION["mensaje"] = $mensaje;
        $_SESSION["tipo"] = $tipo;
        header("Location: index.php");
        exit;
    }

    private function leerFormulario()
    {
        $id = isset($_POST["id"]) ? trim($_POST["id"]) : "";
        $parqueo = new Parqueo();
        $parqueo->setId($id === "" ? null : $id);
        $parqueo->setPlaca(strtoupper(trim(isset($_POST["placa"]) ? $_POST["placa"] : "")));
        $parqueo->setColor(trim(isset($_POST["color"]) ? $_POST["color"] : ""));
        $parqueo->setModelo(trim(isset($_POST["modelo"]) ? $_POST["modelo"] : ""));
        $parqueo->setTipoauto(trim(isset($_POST["tipoauto"]) ? $_POST["tipoauto"] : ""));
        return $parqueo;
    }

    // Devuelve un mensaje de error o null si los datos son correctos
    private function validar($parqueo)
    {
        $id = $parqueo->getId();
        if ($id !== null && (!ctype_digit((string)$id) || (int)$id < 1 || strlen((string)$id) > 9)) {
            return "El Id debe ser un número entero mayor que 0 (o déjelo vacío para que se genere solo).";
        }
        if ($parqueo->getPlaca() === "") {
            return "Ingrese la placa.";
        }
        if (!preg_match('/^[A-Z0-9\- ]{3,10}$/', $parqueo->getPlaca())) {
            return "La placa debe tener de 3 a 10 caracteres (letras, números o guion).";
        }
        if ($parqueo->getColor() === "" || strlen($parqueo->getColor()) > 30) {
            return "Ingrese el color (máximo 30 caracteres).";
        }
        if ($parqueo->getModelo() === "" || strlen($parqueo->getModelo()) > 50) {
            return "Ingrese el modelo (máximo 50 caracteres).";
        }
        if ($parqueo->getTipoauto() === "" || strlen($parqueo->getTipoauto()) > 30) {
            return "Seleccione el tipo de auto.";
        }
        return null;
    }

    // SUBIR FOTOGRAFÍA: devuelve [nombreArchivo, error]
    private function subirFoto()
    {
        if (!isset($_FILES["fotografia"]) || $_FILES["fotografia"]["error"] === UPLOAD_ERR_NO_FILE) {
            return ["", null]; // no se eligió foto
        }
        $archivo = $_FILES["fotografia"];

        if ($archivo["error"] === UPLOAD_ERR_INI_SIZE || $archivo["error"] === UPLOAD_ERR_FORM_SIZE) {
            return ["", "La fotografía es demasiado grande (máximo 2 MB)."];
        }
        if ($archivo["error"] !== UPLOAD_ERR_OK) {
            return ["", "Error al subir la fotografía (código " . $archivo["error"] . ")."];
        }
        if ($archivo["size"] > self::MAX_BYTES) {
            return ["", "La fotografía no debe superar los 2 MB."];
        }

        $permitidos = [
            IMAGETYPE_JPEG => "jpg",
            IMAGETYPE_PNG => "png",
            IMAGETYPE_GIF => "gif",
            IMAGETYPE_WEBP => "webp"
        ];
        $info = @getimagesize($archivo["tmp_name"]);
        if ($info === false || !isset($permitidos[$info[2]])) {
            return ["", "El archivo debe ser una imagen JPG, PNG, GIF o WEBP."];
        }

        if (!is_dir($this->carpetaFotos)) {
            mkdir($this->carpetaFotos, 0755, true);
        }
        $nombre = "auto_" . date("Ymd_His") . "_" . bin2hex(random_bytes(4)) . "." . $permitidos[$info[2]];

        if (!move_uploaded_file($archivo["tmp_name"], $this->carpetaFotos . $nombre)) {
            return ["", "No se pudo guardar la fotografía en public/uploads (revise los permisos de la carpeta)."];
        }
        return [$nombre, null];
    }

    private function borrarFoto($nombre)
    {
        if ($nombre === null || $nombre === "") {
            return;
        }
        $ruta = $this->carpetaFotos . basename($nombre);
        if (is_file($ruta)) {
            @unlink($ruta);
        }
    }
}
