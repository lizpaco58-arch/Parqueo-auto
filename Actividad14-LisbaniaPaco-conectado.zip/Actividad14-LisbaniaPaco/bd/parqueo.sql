-- Base de datos del CRUD "Parqueo - Auto"
-- phpMyAdmin > Importar. Crea la base y la tabla si no existen (no borra datos).
CREATE DATABASE IF NOT EXISTS parqueo CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE parqueo;

CREATE TABLE IF NOT EXISTS auto (
  id INT(11) NOT NULL AUTO_INCREMENT,
  placa VARCHAR(10) NOT NULL,
  color VARCHAR(30) NOT NULL,
  modelo VARCHAR(50) NOT NULL,
  tipoauto VARCHAR(30) NOT NULL,
  fotografia VARCHAR(255) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY placa (placa)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Datos de ejemplo (sin foto; la foto se sube desde el formulario)
INSERT IGNORE INTO auto (id, placa, color, modelo, tipoauto, fotografia) VALUES
(1, '1234-ABC', 'Rojo', 'Toyota Corolla 2018', 'Sedán', ''),
(2, '5678-XYZ', 'Blanco', 'Nissan Frontier 2020', 'Camioneta', ''),
(3, '9012-LPZ', 'Negro', 'Suzuki Vitara 2019', 'Jeep', '');

-- OPCIONAL: si tu tabla "auto" ya existe y su columna id NO es AUTO_INCREMENT
-- (el programa funciona igual), puedes activarlo con:
-- ALTER TABLE auto MODIFY id INT(11) NOT NULL AUTO_INCREMENT;
