<?php
require_once __DIR__ . "/Parqueo.php";

class ParqueoDao
{
    private $conexion;
    private $tabla = "auto";

    // CONSTRUCTOR
    public function __construct($conexion)
    {
        $this->conexion = $conexion;
    }

    // LISTAR AUTOS (con búsqueda opcional)
    public function listar($buscar = "")
    {
        $sql = "SELECT id, placa, color, modelo, tipoauto, fotografia
                FROM {$this->tabla}";
        $parametros = [];

        if ($buscar !== "") {
            $sql .= " WHERE placa LIKE :b1
                      OR color LIKE :b2
                      OR modelo LIKE :b3
                      OR tipoauto LIKE :b4";
            $like = "%" . $buscar . "%";
            $parametros = ["b1" => $like, "b2" => $like, "b3" => $like, "b4" => $like];
        }
        $sql .= " ORDER BY id DESC";

        $stmt = $this->conexion->prepare($sql);
        $stmt->execute($parametros);
        $parqueos = [];

        while ($fila = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $parqueos[] = new Parqueo(
                $fila["id"],
                $fila["placa"],
                $fila["color"],
                $fila["modelo"],
                $fila["tipoauto"],
                $fila["fotografia"]
            );
        }
        return $parqueos;
    }

    // BUSCAR POR ID
    public function buscarPorId($id)
    {
        $sql = "SELECT id, placa, color, modelo, tipoauto, fotografia
                FROM {$this->tabla}
                WHERE id = :id";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute(["id" => $id]);
        $fila = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($fila) {
            return new Parqueo(
                $fila["id"],
                $fila["placa"],
                $fila["color"],
                $fila["modelo"],
                $fila["tipoauto"],
                $fila["fotografia"]
            );
        }
        return null;
    }

    // ¿YA EXISTE ESA PLACA? (se excluye el propio auto al editar)
    public function placaExiste($placa, $idExcluir = null)
    {
        $sql = "SELECT COUNT(*) AS total
                FROM {$this->tabla}
                WHERE placa = :placa AND id <> :id";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute([
            "placa" => $placa,
            "id" => ($idExcluir === null ? 0 : $idExcluir)
        ]);
        $fila = $stmt->fetch(PDO::FETCH_ASSOC);
        return $fila["total"] > 0;
    }

    // INSERTAR
    // Si el usuario deja el Id vacío, MySQL genera el valor con AUTO_INCREMENT.
    // Si escribe un Id manual, se respeta ese valor.
    public function insertar(Parqueo $parqueo)
    {
        $id = $parqueo->getId();

        if ($id === null || $id === "") {
            $sql = "INSERT INTO {$this->tabla}
                    (placa, color, modelo, tipoauto, fotografia)
                    VALUES
                    (:placa, :color, :modelo, :tipoauto, :fotografia)";

            $stmt = $this->conexion->prepare($sql);
            return $stmt->execute([
                "placa" => $parqueo->getPlaca(),
                "color" => $parqueo->getColor(),
                "modelo" => $parqueo->getModelo(),
                "tipoauto" => $parqueo->getTipoauto(),
                "fotografia" => $parqueo->getFotografia()
            ]);
        }

        $sql = "INSERT INTO {$this->tabla}
                (id, placa, color, modelo, tipoauto, fotografia)
                VALUES
                (:id, :placa, :color, :modelo, :tipoauto, :fotografia)";

        $stmt = $this->conexion->prepare($sql);
        return $stmt->execute([
            "id" => $id,
            "placa" => $parqueo->getPlaca(),
            "color" => $parqueo->getColor(),
            "modelo" => $parqueo->getModelo(),
            "tipoauto" => $parqueo->getTipoauto(),
            "fotografia" => $parqueo->getFotografia()
        ]);
    }

    // ACTUALIZAR
    public function actualizar(Parqueo $parqueo)
    {
        $sql = "UPDATE {$this->tabla}
                SET placa = :placa,
                    color = :color,
                    modelo = :modelo,
                    tipoauto = :tipoauto,
                    fotografia = :fotografia
                WHERE id = :id";

        $stmt = $this->conexion->prepare($sql);

        return $stmt->execute([
            "id" => $parqueo->getId(),
            "placa" => $parqueo->getPlaca(),
            "color" => $parqueo->getColor(),
            "modelo" => $parqueo->getModelo(),
            "tipoauto" => $parqueo->getTipoauto(),
            "fotografia" => $parqueo->getFotografia()
        ]);
    }

    // ELIMINAR
    public function eliminar($id)
    {
        $sql = "DELETE FROM {$this->tabla}
                WHERE id = :id";

        $stmt = $this->conexion->prepare($sql);

        return $stmt->execute([
            "id" => $id
        ]);
    }
}
