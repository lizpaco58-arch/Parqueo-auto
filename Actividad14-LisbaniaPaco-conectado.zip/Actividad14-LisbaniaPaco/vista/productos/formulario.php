<?php
$tipos = ["Sedán", "Vagoneta", "Camioneta", "Jeep", "Minibús", "Camión", "Moto", "Otro"];
// Si el tipo guardado no está en la lista (por ejemplo datos antiguos), se agrega
if ($parqueo->getTipoauto() !== "" && !in_array($parqueo->getTipoauto(), $tipos)) {
    array_unshift($tipos, $parqueo->getTipoauto());
}
$fotoActual = $parqueo->getFotografia();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Parqueo - <?php echo $esNuevo ? "Registrar auto" : "Editar auto"; ?></title>
    <link rel="stylesheet" href="public/css/estilos.css">
</head>
<body>
    <header class="cabecera">
        <h1>🅿 Parqueo - Auto</h1>
    </header>

    <main class="contenedor contenedor-estrecho">
        <h2><?php echo $esNuevo ? "Registrar auto" : "Editar auto"; ?></h2>

        <?php if (!empty($error)): ?>
            <div class="alerta alerta-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form class="formulario" method="post" enctype="multipart/form-data"
              action="index.php?accion=<?php echo $esNuevo ? "guardar" : "actualizar"; ?>">

            <label for="id">Id</label>
            <input type="text" id="id" name="id" inputmode="numeric"
                   value="<?php echo htmlspecialchars((string)$parqueo->getId()); ?>"
                   <?php echo $esNuevo ? 'placeholder="Opcional: vacío = automático"' : "readonly"; ?>>

            <label for="placa">Placa</label>
            <input type="text" id="placa" name="placa" maxlength="10" required
                   style="text-transform: uppercase;"
                   value="<?php echo htmlspecialchars($parqueo->getPlaca()); ?>">

            <label for="color">Color</label>
            <input type="text" id="color" name="color" maxlength="30" required
                   value="<?php echo htmlspecialchars($parqueo->getColor()); ?>">

            <label for="modelo">Modelo</label>
            <input type="text" id="modelo" name="modelo" maxlength="50" required
                   value="<?php echo htmlspecialchars($parqueo->getModelo()); ?>">

            <label for="tipoauto">Tipo</label>
            <select id="tipoauto" name="tipoauto" required>
                <option value="">-- Seleccione --</option>
                <?php foreach ($tipos as $t): ?>
                    <option value="<?php echo htmlspecialchars($t); ?>"
                        <?php echo $parqueo->getTipoauto() === $t ? "selected" : ""; ?>>
                        <?php echo htmlspecialchars($t); ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label for="fotografia">Fotografía (JPG, PNG, GIF o WEBP, máx. 2 MB)</label>
            <input type="file" id="fotografia" name="fotografia" accept="image/jpeg,image/png,image/gif,image/webp">

            <div class="vista-previa">
                <img id="previa" alt="Vista previa"
                     src="<?php echo $fotoActual !== "" ? "public/uploads/" . rawurlencode($fotoActual) : ""; ?>"
                     <?php echo $fotoActual === "" ? 'style="display:none;"' : ""; ?>>
                <?php if (!$esNuevo && $fotoActual !== ""): ?>
                    <small>Foto actual. Si elige otra, se reemplazará.</small>
                <?php endif; ?>
            </div>

            <div class="botones">
                <button type="submit" class="btn btn-principal">
                    <?php echo $esNuevo ? "Guardar" : "Actualizar"; ?>
                </button>
                <a href="index.php" class="btn btn-gris">Cancelar</a>
            </div>
        </form>
    </main>

    <script>
        // Vista previa de la imagen elegida antes de guardar
        document.getElementById("fotografia").addEventListener("change", function () {
            var previa = document.getElementById("previa");
            if (this.files && this.files[0]) {
                previa.src = URL.createObjectURL(this.files[0]);
                previa.style.display = "block";
            }
        });
    </script>
</body>
</html>
