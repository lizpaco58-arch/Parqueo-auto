<?php
$mensaje = isset($_SESSION["mensaje"]) ? $_SESSION["mensaje"] : null;
$tipoMensaje = isset($_SESSION["tipo"]) ? $_SESSION["tipo"] : "ok";
unset($_SESSION["mensaje"], $_SESSION["tipo"]);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Parqueo - Autos</title>
    <link rel="stylesheet" href="public/css/estilos.css">
</head>
<body>
    <header class="cabecera">
        <h1>🅿 Parqueo - Auto</h1>
    </header>

    <main class="contenedor">
        <?php if ($mensaje): ?>
            <div class="alerta <?php echo $tipoMensaje === "error" ? "alerta-error" : "alerta-ok"; ?>">
                <?php echo htmlspecialchars($mensaje); ?>
            </div>
        <?php endif; ?>

        <div class="barra">
            <form method="get" action="index.php" class="buscador">
                <input type="text" name="buscar" placeholder="Buscar por placa, color, modelo o tipo"
                       value="<?php echo htmlspecialchars($buscar); ?>">
                <button type="submit" class="btn">Buscar</button>
                <?php if ($buscar !== ""): ?>
                    <a href="index.php" class="btn btn-gris">Limpiar</a>
                <?php endif; ?>
            </form>
            <a href="index.php?accion=nuevo" class="btn btn-principal">+ Nuevo auto</a>
        </div>

        <div class="tabla-contenedor">
            <table class="tabla">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Fotografía</th>
                        <th>Placa</th>
                        <th>Color</th>
                        <th>Modelo</th>
                        <th>Tipo</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (count($parqueos) === 0): ?>
                    <tr><td colspan="7" class="vacio">No hay autos registrados.</td></tr>
                <?php endif; ?>
                <?php foreach ($parqueos as $a): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($a->getId()); ?></td>
                        <td>
                            <?php if ($a->getFotografia() !== ""): ?>
                                <a href="public/uploads/<?php echo rawurlencode($a->getFotografia()); ?>" target="_blank">
                                    <img class="miniatura" alt="Foto del auto"
                                         src="public/uploads/<?php echo rawurlencode($a->getFotografia()); ?>">
                                </a>
                            <?php else: ?>
                                <span class="sin-foto">Sin foto</span>
                            <?php endif; ?>
                        </td>
                        <td><strong><?php echo htmlspecialchars($a->getPlaca()); ?></strong></td>
                        <td><?php echo htmlspecialchars($a->getColor()); ?></td>
                        <td><?php echo htmlspecialchars($a->getModelo()); ?></td>
                        <td><?php echo htmlspecialchars($a->getTipoauto()); ?></td>
                        <td class="acciones">
                            <a class="btn btn-editar" href="index.php?accion=editar&id=<?php echo urlencode($a->getId()); ?>">Editar</a>
                            <form method="post" action="index.php?accion=eliminar"
                                  onsubmit="return confirm('¿Eliminar el auto con placa <?php echo htmlspecialchars(addslashes($a->getPlaca()), ENT_QUOTES); ?>?');">
                                <input type="hidden" name="id" value="<?php echo htmlspecialchars($a->getId()); ?>">
                                <button type="submit" class="btn btn-eliminar">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>
