<?php
session_start();

require_once "config/database.php";
require_once "modelo/Parqueo.php";
require_once "modelo/ParqueoDao.php";
require_once "controlador/ParqueoController.php";

$database = new Database();
$conexion = $database->conectar();
$dao = new ParqueoDao($conexion);
$controller = new ParqueoController($dao);

$accion = isset($_GET["accion"]) ? $_GET["accion"] : "index";

switch ($accion) {
    case "nuevo":
        $controller->nuevo();
        break;
    case "guardar":
        $controller->guardar();
        break;
    case "editar":
        $controller->editar();
        break;
    case "actualizar":
        $controller->actualizar();
        break;
    case "eliminar":
        $controller->eliminar();
        break;
    default:
        $controller->index();
        break;
}
